#include <stdio.h>
#include <wiringPi.h>
#include <stdlib.h>

#include "StepMotor.h"



void StepMotor::longStep(int step)
{
	int i;

	for (i = 0 ; i < step*10 ; ++i)
	{
		digitalWrite (M1_STEP, HIGH) ; 
		digitalWrite (M2_STEP, HIGH) ; 
		delay (1) ;

		digitalWrite (M1_STEP,  LOW) ; 
		digitalWrite (M2_STEP,  LOW) ; 
		delay (1) ;
	}
}

void StepMotor::smallStep(int step)
{
	int i;

	for (i = 0 ; i < step*10 ; ++i)
	{
		digitalWrite (M3_STEP, HIGH) ; 
		delay (1) ;

		digitalWrite (M3_STEP, LOW) ; 
		delay (1) ;
	}
}

/**
 * Initializes the gpio to step motors
 **/
int StepMotor::initIO(){
	stepX = 0;
	stepY = 0;
	coorX = 0;
	coorY = 0;
	scanLine = 0;
	
	wiringPiSetup () ;

	// motor1
	pinMode (M1_STEP, OUTPUT) ;
	pinMode (M1_DIR, OUTPUT) ;

	// motor2
	pinMode (M2_STEP, OUTPUT) ;
	pinMode (M2_DIR, OUTPUT) ;
    
	// motor3
	pinMode (M3_STEP, OUTPUT) ;
	pinMode (M3_DIR, OUTPUT) ;

	return 0;
}

int StepMotor::move(int x, int y){
	int tempX, tempY;

	tempX = x - coorX;
	tempY = y - coorY;

	
	if (tempX < 0)					
		digitalWrite (M3_DIR,  HIGH) ; 		
	else
		digitalWrite (M3_DIR,  LOW) ; 			
	


	if (tempY < 0) {
		
		digitalWrite (M1_DIR,  LOW) ; 
		digitalWrite (M2_DIR,  HIGH) ; 			// back
	} else {

		digitalWrite (M1_DIR,  HIGH) ; 
		digitalWrite (M2_DIR,  LOW) ; 			// stright
	}

	stepX += tempX;
	stepY += tempY;
	coorX = x;
	coorY = y;

	tempX = abs(tempX);
	tempY = abs(tempY);
	
	smallStep(tempX);
	longStep(tempY);


	return 0;
}

int StepMotor::linearStep(){
	int moveX, moveY;
	int endOfSearch = 0;

	moveX = 0;
	moveY = 0;

	if(scanLine == 0){
		printf("line 0!\n");
		printf("Stepx = %d \n StepY = %d\n\n", stepX, stepY);


		if( stepX >= END_X ){
			scanLine += 1;
			moveY = MID_Y;
			moveX = stepX;
		} else {
			moveX = stepX +1;
			moveY = stepY;
		}


	} else if(scanLine == 1) {
		printf("line 1!\n");
		printf("Stepx = %d \n StepY = %d\n\n", stepX, stepY);



		if( stepX <= START_X ){
			scanLine += 1;
			moveY = END_Y;
			moveX = stepX;

		} else {
			moveX = stepX -1;
			moveY = stepY;
		}


	} else if(scanLine == 2) {
		printf("line 2!\n");
		printf("Stepx = %d \n StepY = %d\n\n", stepX, stepY);


		if( stepX >= END_X ){
			scanLine = 0;
			moveY = 0;
			moveX = 0;
			endOfSearch = 1;
		} else {
			moveX = stepX +1;
			moveY = stepY;
		}


	} else {
		printf("Line error!");
	}

	//printf("movex = %d \n movey = %d\n\n", moveX, moveY);

	move(moveX, moveY);

	return endOfSearch;
}

int StepMotor::getX(){ return coorX; }
int StepMotor::getY(){ return coorY; }
