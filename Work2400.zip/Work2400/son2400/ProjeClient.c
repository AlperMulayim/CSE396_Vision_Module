#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <sys/stat.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <arpa/inet.h>
#include<pthread.h>
int callSocket(char *hostname, unsigned short portnum);
int main(int argc , char *argv[]){

	int fd;
	int x,y;
	int i;
	int j;
	char junk;
	if(argc!=3){
		fprintf(stderr,"Usage :  ip adress   port\n");
		return 0;
	}
	fd=callSocket(argv[1],atoi(argv[2]));
	if(fd==-1)
	{
		fprintf(stderr,"Baglanilamadi\n");
		return 0;
	}
	/*while(1){
	
		scanf("%d",&x);
		scanf("%d",&y);
		fprintf(stderr,"x: %d   y: %d  \n",x,y);
		write(fd,&x,sizeof(int));
		write(fd,&y,sizeof(int));

	}*/

while(1){

		read(fd,&junk,1);
		/*write(fd,&x,sizeof(int));

		write(fd,&y,sizeof(int));
		while(read(fd,&junk,1)==0);
				fprintf(stderr,"x :%d  y:%d\n",x,y);*/
//while(read(fd,&junk,1)==0);
	
	for(i=0;i<784;++i)
	{
		x=i;
		y=0;
                
        write(fd,&x,sizeof(int));

		//write(fd,&y,sizeof(int));
		fprintf(stderr,"x :%d  y:%d\n",x,y);
		while(read(fd,&junk,1)==0);
		scanf("%c",&junk);
		usleep(1000);

    }

    for(j=0;j<372;++j)
	{
    	y=j;
		write(fd,&x,sizeof(int));
		write(fd,&y,sizeof(int));
		while(read(fd,&junk,1)==0);
		fprintf(stderr,"x :%d  y:%d\n",x,y);
		usleep(1000);
	}


    for(i=784;i>=0;--i)
	{
    	x=i;
		write(fd,&x,sizeof(int));
		write(fd,&y,sizeof(int));
		while(read(fd,&junk,1)==0);
		fprintf(stderr,"x :%d  y:%d\n",x,y);
		usleep(1000);
    }   

    usleep(1000000);
}






}
int callSocket(char *hostname, unsigned short portnum)
{
	struct sockaddr_in sa;
	
	struct hostent *hp;
	
	int a, s;
	
	if ((hp= gethostbyname(hostname)) == NULL)
	{

		return(-1);
	}
	
	memset(&sa,0,sizeof(sa));



	sa.sin_family= AF_INET;

	sa.sin_port= htons((u_short)portnum);

	inet_pton(AF_INET, hostname, &sa.sin_addr.s_addr);


	
	if ((s= socket(AF_INET,SOCK_STREAM,0)) < 0)
		return(-1);

	if (connect(s,(struct sockaddr *)&sa,sizeof sa) < 0)
	{
	 /* connect */
		close(s);
		return(-1);
	} /* if connect */

	return(s);
}

