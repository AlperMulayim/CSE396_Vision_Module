#ifndef STEPMOTOR
#define STEPMOTOR

#include <wiringPi.h>

#define M1_DIR 29
#define M1_STEP 28
#define M2_DIR 25
#define M2_STEP 24
#define M3_DIR 23
#define M3_STEP 22

#define M1_INIT 460

#define LONG_AXIS 1400

#define START_X 7
#define START_Y 23
#define END_X 200
#define END_Y 105

#define MID_Y 64
#define DIFF_Y 4



class StepMotor {
    public:
        int initIO();
        int move(int x, int y);
        void longStep(int step);
        void smallStep(int step);
        int linearStep();
        int getX();
        int getY();

    private:
        int coorX;
        int coorY;
        int stepX;
        int stepY;
        int scanLine;

};


#endif
