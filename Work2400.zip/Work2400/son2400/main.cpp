#include <iostream>

#include "opencv2/highgui.hpp"
#include "opencv2/imgproc.hpp"
#include <opencv/cvaux.h>
#include <iostream>
#include <time.h>
#include <iomanip>

#include <dirent.h>
#include <sys/stat.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <arpa/inet.h>

#include "StickmanDetector.h"
#include "CableSlope.h"
#include "StepMotor.h"

using  namespace cv;
using  namespace std;

struct ComData {
	int found;
	int x;
	int y;
	int headRadius;
	int headCenterX;
	int headCenterY;
	int bodyPointX;
    int bodyPointY;
} ComData;


int callSocket(char *hostname, unsigned short portnum);
long _map(long x, long in_min, long in_max, long out_min, long out_max);


int main(int argc , char *argv[]){
	
    std::cout << "Hello, World!" << std::endl;
    char key;
    StickmanDetector myDetector(0);
    CableSlope mySlope(1);
    StickManData data;
    int i = 0;
    key = 'a';
    
	//communication
	int fd;
	char junk = 'J';
	struct ComData comData;
	comData.x = 0;
	comData.y = 0;
	comData.found = 0;
	
	
	if(argc!=3){
		fprintf(stderr,"Usage :  ip adress   port\n");
		return 0;
	}
	
	fd=callSocket(argv[1],atoi(argv[2]));
	if(fd==-1)
	{
		fprintf(stderr,"Baglanilamadi\n");
		return 0;
	}
	

    StepMotor stepMotor;
    stepMotor.initIO();
    stepMotor.move(START_X, START_Y);
    
    //start command
	if(read(fd,&junk,1) == -1){
		fprintf(stderr,"Baglanilamadi\n");
		return 0;
	}
	
    while(key != 'q'){
        key = waitKey(25);
		
		comData.x = _map(stepMotor.getX()-START_X, 0, 257, 0, 1050 );
		comData.y = _map(stepMotor.getY()-START_Y, 0, 164, 0, 750 );
		comData.found = 0;

        if( mySlope.detectSingleFrame()) {
            myDetector.captureSingleFrame();
            data = myDetector.getTheCapturedStickMan();

            data.printTheStickMan() ;

            if(data.getHeadRadius() <= 0 ){
                ++i;
				data.printTheStickMan();
				if(stepMotor.linearStep())
                  break;
            } else {
                printf("Buldum !\n");
                data.printTheStickMan();
                
                comData.found = 1;
				comData.headRadius = _map(data.getHeadRadius(), 0, 144, 0, 260 );
				comData.headCenterY = _map(data.getHeadCenterX(), 0, 144, 0, 260 );
				comData.headCenterX = _map(data.getHeadCenterY(), 0, 176, 0, 368 );
				comData.bodyPointY = _map(data.getBodyPointX(), 0, 144, 0, 260 );
				comData.bodyPointX = _map(data.getBodyPointY(), 0, 176, 0, 368 );
                
				if(write(fd,&comData,sizeof(struct ComData)) == -1){
					fprintf(stderr,"Veri gonderilemedi\n");
					stepMotor.move(0,0);
					return 0;
				}
                
                stepMotor.move(0,0);

                break;
            }
			   
			//printf("Main step x: %d - mapped step x: %d \nstep y: %d - mapped step y: %d \n  "

			//send data
			if(write(fd,&comData,sizeof(struct ComData)) == -1){
				fprintf(stderr,"Veri gonderilemedi\n");
				stepMotor.move(0,0);
				return 0;
			}
			
			// get
			if(read(fd,&junk,1) == -1){
				fprintf(stderr,"donus alinamadi\n");
				stepMotor.move(0,0);
				return 0;
			}
        }
        


		
    }
    //myDetector.videoCapturing();



    return 0;
}

int callSocket(char *hostname, unsigned short portnum)
{
	struct sockaddr_in sa;
	
	struct hostent *hp;
	
	int a, s;
	
	if ((hp= gethostbyname(hostname)) == NULL)
	{

		return(-1);
	}
	
	memset(&sa,0,sizeof(sa));



	sa.sin_family= AF_INET;

	sa.sin_port= htons((u_short)portnum);

	inet_pton(AF_INET, hostname, &sa.sin_addr.s_addr);


	
	if ((s= socket(AF_INET,SOCK_STREAM,0)) < 0)
		return(-1);

	if (connect(s,(struct sockaddr *)&sa,sizeof sa) < 0)
	{
	 /* connect */
		close(s);
		return(-1);
	} /* if connect */

	return(s);
}

long _map(long x, long in_min, long in_max, long out_min, long out_max)
{
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

