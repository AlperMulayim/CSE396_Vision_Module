//
// Created by Alper on 13.05.2017.
//


#include <istream>
using  namespace std;

class StickManData {
private:
    int headRadius;
    int headCenterX;
    int headCenterY;
    int bodyPointX;
    int bodyPointY;
    int rectPointX;
    int rectPointY;


public:
    StickManData(int headRadiusV, int headCenterXV, int headCenterYV, int bodyPointXV, int bodyPointYV, int rectPointXV,
                     int rectPointYV);
    StickManData();
    int getHeadRadius() const;

    void setHeadRadius(int headRadius);

    int getHeadCenterX() const;

    void setHeadCenterX(int headCenterX);

    int getRectPointX() const;

    void setRectPointX(int rectPointX);

    int getRectPointY() const;

    void setRectPointY(int rectPointY);

    int getHeadCenterY() const;

    void setHeadCenterY(int headCenterY);

    int getBodyPointX() const;

    void setBodyPointX(int bodyPointX);

    int getBodyPointY() const;

    void setBodyPointY(int bodyPointY);
    void printTheStickMan();

};




