#ifndef COMTHREAD_H
#define COMTHREAD_H
#include <QThread>
#include <QDebug>
#include <QObject>
#include <QTcpSocket>

class ComThread:public QThread
{
     Q_OBJECT
public:
        ComThread(QTcpSocket*  __client);
        void run();
signals:
    void sendPos(int x,int y);
    void tfinished(bool param);

private:

    QTcpSocket* _client;

};


#endif // COMTHREAD_H
