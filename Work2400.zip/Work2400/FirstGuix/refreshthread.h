#ifndef REFRESHTHREAD_H
#define REFRESHTHREAD_H
#include <QThread>
#include <QDebug>
#include <QObject>

class refreshThread:public QThread
{
     Q_OBJECT
public:
        refreshThread();
        void run();
signals:
    void sendIP(QString param);

};

#endif // REFRESHTHREAD_H
