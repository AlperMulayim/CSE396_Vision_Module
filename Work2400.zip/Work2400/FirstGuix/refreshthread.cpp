#include <QHostInfo>
#include <QNetworkInterface>
#include <QTcpSocket>
#include <QTcpServer>
#include <QDebug>

#include "refreshthread.h"


void refreshThread::run(){


    QTcpSocket dnsTestSocket;
       QString localIP="127.0.0.1";    //fall back

           foreach (const QHostAddress &address, QNetworkInterface::allAddresses())
           {
               QString guessedGatewayAddress = address.toString().section( ".",0,2 ) + ".1";

               if (address.protocol() == QAbstractSocket::IPv4Protocol
                   && address != QHostAddress(QHostAddress::LocalHost)
                   )
               {

                   dnsTestSocket.connectToHost(address,1102);


                   if (dnsTestSocket.waitForConnected(3000))
                   {
                       localIP = dnsTestSocket.localAddress().toString();
                       qDebug()<<localIP;
                       break;
                   }
               }
           }

            dnsTestSocket.close();
        emit sendIP(localIP);
}





refreshThread::refreshThread()
{
    qDebug()<<"refreshThread constructor";
}

