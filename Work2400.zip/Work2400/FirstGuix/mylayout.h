#ifndef MYLAYOUT_H
#define MYLAYOUT_H

#include <QObject>
#include <QWidget>

class myLayout : public QWidget
{
    Q_OBJECT
public:
    explicit myLayout(QWidget *parent = 0);
signals:

public slots:
};

#endif // MYLAYOUT_H
