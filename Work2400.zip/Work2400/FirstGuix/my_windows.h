#ifndef MY_WINDOWS_H
#define MY_WINDOWS_H

#include <QMainWindow>
#include <QGraphicsScene>
#include <QBrush>
#include <QPen>
#include <QTcpServer>
#include <QTcpSocket>
#include "comthread.h"
#include "refreshthread.h"


namespace Ui {
class MyWindows;
}

class MyWindows : public QMainWindow
{
    Q_OBJECT

public:
    explicit MyWindows(QWidget *parent = 0);
    ~MyWindows();
    QGraphicsScene * scene;
    void closeEvent(QCloseEvent *event);
private slots:

    void drawSomething(int x,int y);
    void drawStickman(int cornerX,int cornerY,int radius,int bodyBoundX,int bodyBoundY);
    void setButtonEnabled(bool param);

    void getIP(QString param);

    void on_manuelPushButton_clicked();

    void on_startPushButton_clicked();

    void timerUpdate();

    void on_trLang_clicked();

    void on_engLang_clicked();

    void on_refreshB_clicked();

    void on_listenButton_clicked();

    void newConnection();
    void readyRead();
    void disconnected();

private:
    Ui::MyWindows *ui;
    void getAngle(int x1,int y1,int x2,int y2);
    QGraphicsEllipseItem* ellipse;
    QGraphicsRectItem *rectangle;

    QBrush redBrush;
    QBrush transparentBrush;
    QBrush whiteBrush;

    QPen redpen;
    QPen bluepen;
    QPen transparentPen;

    QTimer *timer;
    ComThread * myComThread;
    refreshThread * myRefreshThread;
    QTcpServer * server;
    QTcpServer * correctionServer;
    QTcpSocket * client;
    int language;
    int bytes;
};

#endif // MY_WINDOWS_H
