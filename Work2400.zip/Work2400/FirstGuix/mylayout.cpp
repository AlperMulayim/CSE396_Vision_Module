#include "mylayout.h"

myLayout::myLayout(QWidget *parent) : QWidget(parent)
{

}


void myLayout::mousePressedEvent(QMouseEvent *me) {
   if (me->buttons() ^ me->button()) {QFrame::mousePressedEvent(me); return;}

    if (me->button() == QMouseEvent::LeftMouse) {
        emit(myMousePressedSignal());
        // here you shoud remember click event...
        me->accept();
        return;
    }

    QFrame::mousePressedEvent(me);
}

void myLayout::mouseRelessedEvent(QMouseEvent *me) {
   if (me->button()) {QFrame::mouseReleasedEvent(me); return;}

   // here emit released and click signal if clicked... if not just call mouseReleasedEvent
   // from the base class and forget about clicked, if clicked...

   // Anyway each widget receives those events, not only QFrame....
}
