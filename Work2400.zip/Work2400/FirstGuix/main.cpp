#include <QApplication>
#include <QDebug>
#include <QRect>
#include <QScreen>
#include "my_windows.h"

using namespace std;


int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    MyWindows w;/*
    QScreen *screen = QGuiApplication::primaryScreen();
    QRect  screenGeometry = screen->geometry();
    int height = screenGeometry.height();
    int width = screenGeometry.width();

    w.setFixedSize(width,height);*/

    w.setWindowTitle("Find The Stickman");
    w.setWindowIcon(QIcon("C:/Users/aemin/Desktop/FirstGui/indir.png"));
   // w.setStyleSheet("background-color: #2F3233;");
    w.show();
   // w.setStyleSheet("background-color:skyblue");


    return app.exec();
}
