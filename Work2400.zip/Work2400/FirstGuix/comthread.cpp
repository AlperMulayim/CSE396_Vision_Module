#include <QtCore>
#include <QDebug>
#include "comthread.h"


void ComThread::run(){

    qDebug()<<"comthread run!\n";

 /*   QFile file("s.txt");

       if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
           return;
         QTextStream in(&file);

       while (!in.atEnd()) {

            QString line = in.readLine();

            QStringList list = line.split(" ",QString::SkipEmptyParts);

            foreach(QString num, list)
                qDebug() << num.toInt() << endl;
            qDebug()<<list.at(0);
            int x=list.at(0).toInt();*/

    /*  }


   file.close();*/

            /*int x=0,y=0;

            for(int i=0;i<784;++i){
                x=i;
                emit sendPos(x,y);
                QThread::msleep(10);


           }

           for(int j=0;j<372;++j){
               y=j;
               emit sendPos(x,y);
               QThread::msleep(10);


           }


           for(int i=784;i>=0;--i){
               x=i;
               emit sendPos(x,y);
               QThread::msleep(10);

          }*/

        int x,y;
        unsigned int bufcount=0;
        int count =0;
        char junk='a';
        int flag=1;
        _client->write(&junk);
        _client->flush();
        _client->waitForBytesWritten(-1);
              while(flag){
                  char buffer[50];
                  int i=0;
                  int totalbyte=0;

               do{
                       //_client->waitForReadyRead(-1);
                       i=_client->read(&buffer[totalbyte],1);
                       if(i==-1){
                           flag=0;
                           break;
                       }
                       else

                           totalbyte+=i;
                           // qDebug()<<i;
                   }while(totalbyte<sizeof(int)*2);
                     buffer[totalbyte]='\0';
                     x=(*((int*)buffer));
                     y=(*((int*)(buffer+sizeof(int))));
                     qDebug() << x;
                     qDebug() << y;
                      _client->write(&junk);

                      _client->flush();
                      _client->waitForBytesWritten(-1);
                      qDebug()<<"Okudum yazdim";
              }
    emit tfinished(true);
}

ComThread::ComThread(QTcpSocket* __client){

    qDebug()<<"comthread constructor!\n";
    _client=__client;
}
