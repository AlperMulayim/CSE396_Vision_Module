#include <QMessageBox>
#include <QGraphicsScene>
#include <QDebug>
#include <QTimer>
#include <QGraphicsRectItem>
#include <QFile>
#include <QHostInfo>
#include <QNetworkInterface>
#include <QTcpSocket>
#include <QTcpServer>
#include <QtMath>
#include "comthread.h"
#include "refreshthread.h"
#include "my_windows.h"
#include "ui_mywindows.h"

struct ComData{
    int found;
    int x;
    int y;
    int headRadius;
    int headCenterX;
    int headCenterY;
    int bodyPointX;
    int bodyPointY;
}ComData;

MyWindows::MyWindows(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MyWindows)

{
    bytes=0;
    correctionServer=new QTcpServer(this);

    qDebug() << "Listening:" << correctionServer->listen(QHostAddress::Any, 1102);

    ui->setupUi(this);
    server=NULL;
    /* COMBO BOX ICIN VERILER GIRILDI */


    ui->methodCBox->addItem("Choose Searching Method");
    ui->methodCBox->addItem("Linear Search");
    ui->methodCBox->addItem("Zigzag Search");
    ui->methodCBox->addItem("Best Search");


    /* CIZIM ICIN SCENE SET EDILDI*/
    scene = new QGraphicsScene(this);

    scene->setSceneRect(0,0,1045   ,745);

    ui->mapShow->setFixedSize(1050 ,750);
    ui->mapShow->setScene(scene);
   // ui->mapShow->set

    /*KALEMLERIN CIZIM BOYUTU ve RENKLERI SET EDILIR*/
    transparentBrush.setColor(Qt::transparent);
    redBrush.setColor(Qt::red);

    bluepen.setColor(Qt::blue);
    transparentPen.setColor(Qt::white);
    redpen.setColor(Qt::red);
    whiteBrush.setColor(Qt::white);
    transparentPen.setWidth(4);
    redpen.setWidth(4);
    bluepen.setWidth(4);


    /*scene->addEllipse(25,400,50,50,redpen,transparentBrush);
    scene->addLine(70,445,125,500,redpen);
    scene->addLine(125,500,130,550,redpen);
    scene->addLine(125,500,180,500,redpen);

    scene->addLine(97,472,100,425,redpen);
    scene->addLine(97,472,40,475,redpen);*/


   // scene->addEllipse(200,100,100,35,redpen,transparentBrush);

   // scene->addRect(200,100,35,100,redpen,transparentBrush);
   // rectangle=scene->addRect(0,0,100,35,redpen,transparentBrush);
   // rectangle->setRect(0,0,50,50);
   // scene->addLine(200,100,150,75);
    //scene->addEllipse()
    myComThread=NULL;
    rectangle=NULL;
    language=1;
    ui->TimerShow->setText("0");

    ui->engLang->setStyleSheet("border-image: url(/home/aek/Desktop/FirstGuix/britain.png);");

    ui->manuelPushButton->setStyleSheet("border-image: url(/home/aek/Desktop/FirstGuix/umanuel.png);");

    ui->trLang->setStyleSheet("border-image: url(/home/aek/Desktop/FirstGuix/Turkish.png);");

    qDebug()<<QHostInfo::localHostName().toLocal8Bit();

   /* QPixmap * mypix = new QPixmap("/home/aek/Desktop/FirstGuix/britain.png");
    ui->rulerx->setPixmap(*mypix);
    delete mypix;*/
    ui->rulerx->setStyleSheet("border-image: url(/home/aek/Desktop/FirstGuix/rullerx.jpg);");
    ui->rulery->setStyleSheet("border-image: url(/home/aek/Desktop/FirstGuix/rullery.jpg);");
    //drawStickman(100,100,21,200,200);
    ui->startPushButton->setEnabled(false);
    timer=NULL;
}
MyWindows::~MyWindows()
{
    delete ui;

    if(myComThread!=NULL){

        myComThread->terminate();
        delete myComThread;

    }
}



void MyWindows::on_startPushButton_clicked()
{



    rectangle=NULL;
    scene->clear();
    if(language==1)
    ui->CurSitValue->setText("Target Not Found");
    else
      ui->CurSitValue->setText("Hedef Bulunamadı");
    ui->CurSitValue->setStyleSheet("color:red");




    /*myComThread = new ComThread(client);

    connect(myComThread,SIGNAL(sendPos(int,int)),this,SLOT(drawSomething(int,int)));
    connect(myComThread,SIGNAL(tfinished(bool)),this,SLOT(setButtonEnabled(bool)));

    myComThread->start();*/


    /*Start basinca timer olusturulur*/
    char junk='a';
    qDebug()<<"patlamadı";
    client->write(&junk,1);
    /*client->waitForBytesWritten(-1);
    client->flush();*/
        qDebug()<<"patlamadı";
    if(timer==NULL)
    timer=new QTimer(this);
    qDebug()<<"patlamadı4";
    connect(timer,SIGNAL(timeout()),this,SLOT(timerUpdate()));
    ui->TimerShow->setText(QString::number(0.0));
    timer->start(100);

    //qDebug()<<"patlamadı5";
    /*make button disable*/
    ui->startPushButton->setEnabled(false);


}
void MyWindows::timerUpdate(){

    //qDebug()<<"Timer executed!\n";
    QString  temp=ui->TimerShow->text();
    QStringList list = temp.split(" ",QString::SkipEmptyParts);

    double second = list.at(0).toDouble();
    second+=0.1;
    if(language==0)
    ui->TimerShow->setText(QString::number(second)+" saniye");
    else if(language==1)
        ui->TimerShow->setText(QString::number(second)+" seconds");
}





void MyWindows::drawSomething(int x,int y){
  //  qDebug()<<"Çalıştı";

    if(rectangle==NULL){
        rectangle=scene->addRect(0,0,260,368,redpen,transparentBrush);

    }
    else{

       rectangle->setRect(x,y,260,368);

    }

    qDebug()<<x;



  // while(1){
     // ellipse = scene->addEllipse(15+x,40,35,35,redpen,transparentBrush);
     // ++x;
       // this-

  /*  rectangle=scene ->addRect(0,0,158,225,redpen,transparentBrush);

      rectangle=scene ->addRect(158,0,158,225,redpen,transparentBrush);
       rectangle=scene ->addRect(158*2,0,158,225,redpen,transparentBrush);
         rectangle=scene ->addRect(158*3,0,157,225,redpen,transparentBrush);
         rectangle=scene ->addRect(158*3,0,157,225,transparentPen,transparentBrush);


    scene->addLine(75,70,30,90,redpen);
    scene->addLine(50,60,100,80,redpen);
    scene->addLine(75,70,90,40,redpen);

    scene->addLine(100,80,120,60,redpen);
    scene->addLine(100,80,120,120,redpen);*/

}



void MyWindows::on_manuelPushButton_clicked()
{
      QMessageBox::about(this,"User Manuel","Kullanım klavuzu buraya yazilacak!\nKullanım klavuzu buraya yazilacak!\nKullanım klavuzu buraya yazilacak!\nKullanım klavuzu buraya yazilacak!\n");
}



void MyWindows::setButtonEnabled(bool param){
    qDebug()<<"setButtonEnabled";

    timer->stop();


    ui->startPushButton->setEnabled(true);

    if(param==true){

        if(language==1)
        ui->CurSitValue->setText("Target Found");
        else if(language==0)
            ui->CurSitValue->setText("Hedef Bulundu");
        ui->CurSitValue->setStyleSheet("color:green");
    }


    scene->addEllipse(25,400,50,50,bluepen,transparentBrush);
   // scene ->addRect(25,400,50,50,redpen,transparentBrush);
    scene->addLine(70,445,125,500,bluepen);
    scene->addLine(125,500,130,550,bluepen);
    scene->addLine(125,500,180,500,bluepen);

    scene->addLine(97,472,100,425,bluepen);
    scene->addLine(97,472,40,475,bluepen);



}



void MyWindows::on_trLang_clicked()
{
    language=0;
    ui->Header->setText("Çöp Adamı Bul");
    ui->MapH->setText("Harita");
     ui->ControlPanelHeader->setText("Kontrol Paneli");
     ui->startPushButton->setText("Başlat");
      ui->CurrentSituation->setText("Mevcut Durum");
      ui->TimerH->setText("Kronometre");
      if(ui->CurSitValue->text()=="Target Not Found")
          ui->CurSitValue->setText("Hedef Bulunamadı");
      else if(ui->CurSitValue->text()=="Target Found")
          ui->CurSitValue->setText("Hedef Bulundu");

      ui->curIp->setText("Mevcut IP Adresi");
      ui->refreshB->setText("Yenile");
       ui->deviceStath->setText("Cihaz Durumu");
       ui->portNumberH->setText("Port Numarası");
        ui->listenButton->setText("Portu Dinle");
}

void MyWindows::on_engLang_clicked()
{
    language=1;
    ui->Header->setText("Find The Stickman ");
     ui->MapH->setText("Map");
     ui->ControlPanelHeader->setText("Control Panel");
      ui->startPushButton->setText("Start");
      ui->CurrentSituation->setText("Current Situation");
       ui->TimerH->setText("Timer");

       if(ui->CurSitValue->text()=="Hedef Bulunamadı")
           ui->CurSitValue->setText("Target Not Found");
       else if(ui->CurSitValue->text()=="Hedef Bulundu")
           ui->CurSitValue->setText("Target Found");

        ui->curIp->setText("Current IP Adress");
        ui->refreshB->setText("Refresh");
        ui->deviceStath->setText("Device Status");
         ui->portNumberH->setText("Port Number");
         ui->listenButton->setText("Listen The Port");
}

/*thread olustur burasi icin*/
void MyWindows::on_refreshB_clicked()
{
    ui->refreshB->setEnabled(false);
    myRefreshThread = new refreshThread();
    connect(myRefreshThread,SIGNAL(sendIP(QString)),this,SLOT(getIP(QString)));
    myRefreshThread->start();


}

void MyWindows::getIP(QString param){

    qDebug()<<"Getting IP: " <<param;

    ui->ipValue->setText(param);
    ui->ipValue->setStyleSheet("color:red");
    ui->refreshB->setEnabled(true);
    delete(myRefreshThread);
}

void MyWindows::on_listenButton_clicked()
{
    QString temp=ui->portNumberVal->text();

    if(temp!=""){

         int portNumber = ui->portNumberVal->text().toInt();

         if(server!=NULL)
        {
           server->close();
           delete(server);
         }

          server = new QTcpServer(this);

         connect(server, SIGNAL(newConnection()), SLOT(newConnection()));
            qDebug() << "Listening:" << server->listen(QHostAddress::Any, portNumber);
    }
}
void MyWindows::newConnection(){

    while (server->hasPendingConnections())
    {
           QTcpSocket *socket = server->nextPendingConnection();
           connect(socket, SIGNAL(readyRead()), SLOT(readyRead()));
           connect(socket,SIGNAL(disconnected()),SLOT(disconnected()));
           client=socket;
     }
    // client = static_cast<QTcpSocket*>(sender());
    ui->deviceStat->setText("<font color='green'>Connected</font>");
     ui->startPushButton->setEnabled(true);
}


void MyWindows::readyRead()
{
    qDebug()<<"readyRead GELDİ";
   // client = static_cast<QTcpSocket*>(sender());
 //   ui->deviceStat->setText("<font color='green'>Connected</font>");
    int x=-1;
    int y=0;
    int count =0;
    char junk='a';
    char buffer[40];
    struct ComData mydata;
    int t=0;
   //while (client->bytesAvailable() > 0)
  //  {

            t=client->read((char*)&mydata,sizeof(struct ComData));
              /*qDebug()<<"bytes:"<<bytes<<"okunan:"<<t;
              if(t==0)
              {
                  qDebug()<<"HATA";
              }*/
            /*bytes+=t;
            if(bytes==(sizeof(struct ComData)))
            {
                bytes=0;
              //  qDebug()<<buffer[0]<<buffer[1]<<buffer[2]<<buffer[3];
                //client->write(&junk);
               // client->flush();
                x=*((int*)buffer);
              //  y=*((int*)(buffer+(sizeof(int))));*/
                client->write(&junk,1);
                drawSomething(mydata.x,mydata.y);
                if(mydata.found==1)
                {
                    drawStickman(mydata.x+mydata.headCenterX-+mydata.headRadius,
                                 mydata.y+mydata.headCenterY-mydata.headRadius,
                                 mydata.headRadius,
                                 mydata.x+mydata.bodyPointX,mydata.y+mydata.bodyPointY);
                    qDebug()<<"BULUNDU";
                    ui->startPushButton->setEnabled(true);
                    timer->stop();
                    timer=NULL;
                }
                //client->waitForBytesWritten(-1);
                //client->flush();

                qDebug()<<"x"<<mydata.x<<" y"<<mydata.y;

          // }
    //}


    qDebug()<<"readyRead geldi\n";
}

void MyWindows::disconnected(){


    ui->deviceStat->setText("<font color='red'>Disconnected</font>");
     ui->startPushButton->setEnabled(false);

}


void MyWindows::closeEvent(QCloseEvent *event){

    qDebug()<<"closing";
    if(correctionServer!=NULL){
    correctionServer->close();
   // correctionServer->
    }
    if(server!=NULL)
    server->close();
}

void MyWindows::drawStickman(int cornerX, int cornerY, int radius,int bodyBoundX, int bodyBoundY){

    int middleX,middleY;
    int difX,difY;
   scene->addLine(cornerX+radius,cornerY+radius,bodyBoundX,bodyBoundY,bluepen);
   scene->addEllipse(cornerX,cornerY,2*radius,2*radius,bluepen, QBrush(Qt::white));

   middleX=(cornerX+radius +  bodyBoundX)/2.0;
   middleY=(cornerY+radius + bodyBoundY)/2.0;

   difX=bodyBoundX-(cornerX+radius);
   difY=bodyBoundY-(cornerY+radius);

   if(difX>=0 && difY>=0)
   {
       qDebug()<<"kol 1";
       scene->addLine(middleX,middleY,middleX+radius,middleY-20,bluepen);

       scene->addLine(middleX,middleY,middleX,middleY+radius,bluepen);

       qDebug()<<"bacak 1";
       scene->addLine(bodyBoundX,bodyBoundY,bodyBoundX+radius,bodyBoundY-20,bluepen);

       scene->addLine(bodyBoundX,bodyBoundY,bodyBoundX,bodyBoundY+radius,bluepen);


   }
   else if(difX>=0 && difY<=0)
   {
       qDebug()<<"kol 2";
       scene->addLine(middleX,middleY,middleX,middleY-radius,bluepen);

       scene->addLine(middleX,middleY,middleX+radius,middleY,bluepen);

       qDebug()<<"bacak 2";
       scene->addLine(bodyBoundX,bodyBoundY,bodyBoundX,bodyBoundY-radius,bluepen);

       scene->addLine(bodyBoundX,bodyBoundY,bodyBoundX+radius,bodyBoundY,bluepen);
   }
   else if(difX<=0 && difY<=0)
   {
       qDebug()<<"kol 3";
       scene->addLine(middleX,middleY,middleX-radius,middleY+25,bluepen);

       scene->addLine(middleX,middleY,middleX,middleY-radius,bluepen);


       qDebug()<<"bacak 3";
       scene->addLine(bodyBoundX,bodyBoundY,bodyBoundX-radius,bodyBoundY+25,bluepen);

       scene->addLine(bodyBoundX,bodyBoundY,bodyBoundX,bodyBoundY-radius,bluepen);

   }
   else if(difX<=0 && difY>=0)
   {
       qDebug()<<"kol 4";
       scene->addLine(middleX,middleY,middleX,middleY+radius,bluepen);

       scene->addLine(middleX,middleY,middleX-radius,middleY,bluepen);
       qDebug()<<"bacak 4";
       scene->addLine(bodyBoundX,bodyBoundY,bodyBoundX,bodyBoundY+radius,bluepen);

       scene->addLine(bodyBoundX,bodyBoundY,bodyBoundX-radius,bodyBoundY,bluepen);

   }


}
void MyWindows::getAngle(int x1,int y1,int x2,int y2)
{

   /* float degrees = 180.0f;
    float radians = qDegreesToRadians(degrees);

    See also qRadiansToDegrees();
    qAsin(qFabs(y1-y2)-qFabs());*/

}
